package java0520;

public class Study06 {

	public static void main(String[] args) {
		
		int[][] numbers = new int[9][9];
		int[] a = {0, 3, 4, 6, 2, 7, 5, 1, 9};
		int b = 0;
		
		for (int i = 0; i < numbers.length; i++) {
			for (int j = 0; j < numbers.length; j++) {
				if(j == i) {
					numbers[i][j] = 8;
					b++;
				} else {
					numbers[i][j] = a[b];
				}
				System.out.print(numbers[i][j] + "\t");
			}
			System.out.println();
		}
		
	}

}
