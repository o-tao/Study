package java0523;

public class asdf {

	public static void main(String[] args) {
		 
		int sum = 0;
		int[] numbers = {2, 4, 6, 8, 10};
		
		for (int i = 0; i < numbers.length; i++) {
			sum += numbers[i];
		}
		
		System.out.println("numbers 배열 요소의 합: " + sum);

	}

}
