package testJdbc0527;

public class Study01 {

	public static void main(String[] args) {
		
		// mariadb 접속
		new Study01_1().접속();

	}

}
