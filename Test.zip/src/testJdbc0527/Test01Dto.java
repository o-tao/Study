package testJdbc0527;

public class Test01Dto {
	
	private int no;
	private String name;
	private String gender;
	private String ability;
	private String groupname;
	private String role;
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAbility() {
		return ability;
	}
	public void setAbility(String ability) {
		this.ability = ability;
	}
	public String getGroupname() {
		return groupname;
	}
	public void setGroupname(String groupname) {
		this.groupname = groupname;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "Test01_1 [no=" + no + ", name=" + name + ", gender=" + gender + ", ability=" + ability + ", groupname="
				+ groupname + ", role=" + role + "]";
	}
	
	
	

}
