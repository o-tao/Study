package testJdbc0527;

public class TestMain {

	public static void main(String[] args) {
		
		new Test01().시작();

	}

}
