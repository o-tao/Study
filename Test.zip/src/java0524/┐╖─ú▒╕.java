package java0524;

public class 옆친구 {
	
	옆친구() {}
	옆친구(int b) {}
	옆친구(String b) {}
	

	void 함수() {}
	private void 함수(int a) {}
	private void 함수(String a) {}
	
}
