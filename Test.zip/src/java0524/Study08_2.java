package java0524;

public class Study08_2 extends Study08_1 {

	int a;
	
	Study08_2() {super(4);}
	
	Study08_2(int a) {
		super.a = a;
	}
	
	void 함수2() {
		
	}
	
}
