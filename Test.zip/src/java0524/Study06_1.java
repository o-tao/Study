package java0524;

public class Study06_1 {
	
	void 함수() {
		
		
	}

}
