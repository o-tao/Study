package java0524;

public class Study03 {

	public static void main(String[] args) { // 오버로딩 기본
		a();
		a(1);
		a("");

	}
	
	static void a() {
		
	}
	
	static void a(int a) {
		
	}
	
	static void a(String a) {
		
	}

}
