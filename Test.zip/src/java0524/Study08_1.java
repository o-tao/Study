package java0524;

public class Study08_1 {
	
	Study08_1() {}
	Study08_1(int a) {this.a = a;}
	
	int a;
	
	void 함수() {
		System.out.println(a);
	}

}
