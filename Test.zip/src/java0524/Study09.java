package java0524;

public class Study09 {

	public static void main(String[] args) {
		
		new Study09_1(3, 6);

	}


}
