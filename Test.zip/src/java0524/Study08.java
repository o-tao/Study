package java0524;

public class Study08 {

	public static void main(String[] args) {

		Study08_2 s8 = new Study08_2();
		s8.함수();
		s8.함수2();
		
	}

}
