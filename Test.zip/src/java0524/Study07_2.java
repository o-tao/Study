package java0524;

public class Study07_2 extends Study07_1 {
	
	void 호출() { // method
		함수();
	}
	
	void 함수() {
		System.out.println("함수111");
	}
	

	@Override
	void 함수2() { // Override
		
	}
	
	void 함수2(int a) { // OverLoding
		
	}

}
