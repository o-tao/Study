package java0524;

public class Study06 {

	public static void main(String[] args) {
		
		new Study06_1().함수();
		
//		new Study06_2().함수(); -> new 키워드를 사용하지 않고 메소드 실행하기 -> 접근제어자에 static 넣어주기
		Study06_2.함수();
		System.out.println(Study06_2.a);
	}

}
