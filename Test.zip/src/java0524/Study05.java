package java0524;

public class Study05 {

	public static void main(String[] args) {
		
//		new Study05_1(); // <- 실행 또는 호출
		Study05_1 s51 = new Study05_1(); // <- 실행 또는 호출
		System.out.println(s51);
		s51.b();
	}

}
