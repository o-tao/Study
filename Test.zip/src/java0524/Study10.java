package java0524;

public class Study10 {

	public static void main(String[] args) {
		
		new Study10_1(0, 5);

	}

}
