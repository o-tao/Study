package java0524;

public abstract class Study07_1 {
	
	void 함수() {
		System.out.println("함수");
	}
	
	abstract void 함수2(); // 추상적

}
