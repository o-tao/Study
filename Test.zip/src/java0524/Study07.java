package java0524;

public class Study07 {

	public static void main(String[] args) {
		
		Study07_2 a = new Study07_2();
		
		a.함수();

	}

}
