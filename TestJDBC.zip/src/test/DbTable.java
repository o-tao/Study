package test;

public class DbTable {

	// 테이블 정의서를 보고 필드(변수)를 선언하시오.

}
